#ifndef CONFIG_H
#define CONFIG_H

#define DEFAULT_GPU_BATCH 1048576

#endif